﻿using BeautySalon.Model;
using System;
using System.ComponentModel;
using System.IO;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BeautySalon.Classes
{
    public class ServiceVM : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string prop) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));

        public long ServiceID { get; set; }

        private string _serviceName;
        public string ServiceName
        {
            get => _serviceName;
            set { _serviceName = value; OnPropertyChanged(nameof(ServiceName)); }
        }

        private int _duration;
        public int Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(nameof(Duration)); OnPropertyChanged(nameof(CostAndDuration)); }
        }

        private int _cost;
        public int Cost
        {
            get => _cost;
            set { _cost = value; OnPropertyChanged(nameof(Cost)); OnPropertyChanged(nameof(CostDisplay)); OnPropertyChanged(nameof(FinalPriceDisplay)); OnPropertyChanged(nameof(CostAndDuration)); }
        }

        private double _sale;
        public double Sale
        {
            get => _sale;
            set { _sale = value; OnPropertyChanged(nameof(Sale)); OnPropertyChanged(nameof(FinalPriceDisplay)); OnPropertyChanged(nameof(FinalPriceVisibility)); OnPropertyChanged(nameof(OriginalPriceDecoration)); OnPropertyChanged(nameof(SaleText)); }
        }

        private string _imagePath;
        public string ImagePath
        {
            get => _imagePath;
            set { _imagePath = value; OnPropertyChanged(nameof(ImagePath)); OnPropertyChanged(nameof(Thumbnail)); }
        }

        public ImageSource Thumbnail => LoadImageSafe(ImagePath);

        public string CostDisplay => Cost.ToString("N0") + " ₽";

        public string FinalPriceDisplay => Sale > 0 ? $"{Math.Round(Cost * (1.0 - Sale), 0):N0} ₽" : "";

        public TextDecorationCollection OriginalPriceDecoration => Sale > 0 ? System.Windows.TextDecorations.Strikethrough : null;

        public System.Windows.Visibility FinalPriceVisibility => Sale > 0 ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;

        public Brush ImageAreaBackground => Sale > 0 ? new SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 74, 109)) :
                                                             new SolidColorBrush(System.Windows.Media.Color.FromRgb(225, 228, 255));

        public string SaleText => Sale > 0 ? $"Скидка: {Math.Round(Sale * 100)}%" : "";

        public string CostAndDuration => $"{CostDisplay} за {Duration} мин.";

        public static ServiceVM FromEntity(Services s)
        {
            return new ServiceVM
            {
                ServiceID = s.ServiceID,
                ServiceName = s.ServiceName,
                Duration = s.Duration,
                Cost = s.Cost,
                Sale = (double)s.Sale,
                ImagePath = s.Image
            };
        }

        public void UpdateFromEntity(Services s)
        {
            ServiceName = s.ServiceName;
            Duration = s.Duration;
            Cost = s.Cost;
            Sale = (double)s.Sale;
            ImagePath = s.Image;
        }

        private BitmapImage LoadImageSafe(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return null;

            try
            {
                path = path.Trim('"');

                if (!Path.IsPathRooted(path))
                    path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);

                if (!File.Exists(path)) return null;

                BitmapImage bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(path);
                bmp.DecodePixelWidth = 200;
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }
    }
}
