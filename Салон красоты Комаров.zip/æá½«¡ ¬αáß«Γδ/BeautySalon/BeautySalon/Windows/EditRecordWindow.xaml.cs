﻿using BeautySalon.Model;
using System;
using System.Linq;
using System.Windows;

namespace BeautySalon
{
    public partial class EditRecordWindow : Window
    {
        private Records _record;
        private BeautySalonEntities2 db = new BeautySalonEntities2();

        public event EventHandler RecordSaved;

        public string WindowTitle => _record == null ? "Добавление записи" : "Редактирование записи";
        public string RecordDate { get; set; }

        public EditRecordWindow(Records record = null)
        {
            InitializeComponent();
            _record = record;
            DataContext = this;
            LoadComboBoxes();
            LoadData();
        }
        private void LoadComboBoxes()
        {
            var services = db.Services.ToList();
            if (ServiceCombo != null) ServiceCombo.ItemsSource = services;

            var clientsFromDb = db.Clients.ToList();
            var clients = clientsFromDb
                .Select(c => new { c.ClientID, FullName = $"{c.Surname} {c.Name} {c.MiddleName}".Trim() })
                .ToList();

            if (ClientCombo != null) ClientCombo.ItemsSource = clients;
        }
        private void LoadData()
        {
            if (_record != null)
            {
                if (ServiceCombo != null) ServiceCombo.SelectedValue = _record.ServiceID;
                if (ClientCombo != null) ClientCombo.SelectedValue = _record.ClientID;
                RecordDate = _record.ServiceStart;
            }
            else
            {
                RecordDate = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            }

            if (DateTextBox != null) DateTextBox.Text = RecordDate;

            DataContext = null;
            DataContext = this;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ServiceCombo?.SelectedValue == null || ClientCombo?.SelectedValue == null || string.IsNullOrWhiteSpace(DateTextBox?.Text))
            {
                MessageBox.Show("Заполните все поля", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!DateTime.TryParseExact(DateTextBox.Text.Trim(), "dd.MM.yyyy HH:mm:ss", null, System.Globalization.DateTimeStyles.None, out DateTime dt))
            {
                MessageBox.Show("Неверный формат даты. Используйте формат: дд.мм.гггг чч:мм:сс", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                Records record;
                if (_record == null)
                {
                    record = new Records();
                    long maxId = db.Records.Any() ? db.Records.Max(r => r.RecordID) : 0;
                    record.RecordID = maxId + 1;
                    db.Records.Add(record);
                }
                else
                {
                    record = db.Records.Find(_record.RecordID);
                    if (record == null) throw new Exception("Запись не найдена");
                }

                record.ServiceID = (long)ServiceCombo.SelectedValue;
                record.ClientID = (long)ClientCombo.SelectedValue;
                record.ServiceStart = dt.ToString("dd.MM.yyyy HH:mm:ss");

                db.SaveChanges();
                RecordSaved?.Invoke(this, EventArgs.Empty);

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
