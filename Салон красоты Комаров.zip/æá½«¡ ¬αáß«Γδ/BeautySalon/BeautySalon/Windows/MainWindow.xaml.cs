﻿using BeautySalon.Classes;
using BeautySalon.Model;
using BeautySalon.Windows;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace BeautySalon
{
    public partial class MainWindow : Window
    {
        private BeautySalonEntities2 db = new BeautySalonEntities2();
        private List<ServiceVM> allServices = new List<ServiceVM>();
        private ObservableCollection<ServiceVM> displayed = new ObservableCollection<ServiceVM>();
        public bool IsAdmin { get; set; } = false;

        public MainWindow(bool isAdminMode)
        {
            InitializeComponent();
            IsAdmin = isAdminMode;
            DataContext = this;
            InitializeSaleFilterOptions();
            LoadServices();
        }

        private void LoadServices()
        {
            try
            {
                var services = db.Services.ToList();
                allServices = services.Select(s => ServiceVM.FromEntity(s)).ToList();
                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки услуг: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InitializeSaleFilterOptions()
        {
            SaleFilterCombo.Items.Clear();
            SaleFilterCombo.Items.Add("Все");
            SaleFilterCombo.Items.Add("0–5%");
            SaleFilterCombo.Items.Add("5–15%");
            SaleFilterCombo.Items.Add("15–30%");
            SaleFilterCombo.Items.Add("30–70%");
            SaleFilterCombo.Items.Add("70–100%");
            SaleFilterCombo.SelectedIndex = 0;
        }

        private void ApplyFilters()
        {
            string search = SearchBox.Text?.Trim().ToLower() ?? "";
            int filterIndex = SaleFilterCombo.SelectedIndex;
            var query = allServices.AsEnumerable();

            if (!string.IsNullOrEmpty(search))
                query = query.Where(s => s.ServiceName.ToLower().Contains(search));

            switch (filterIndex)
            {
                case 1: query = query.Where(s => s.Sale >= 0 && s.Sale < 0.05); break;
                case 2: query = query.Where(s => s.Sale >= 0.05 && s.Sale < 0.15); break;
                case 3: query = query.Where(s => s.Sale >= 0.15 && s.Sale < 0.3); break;
                case 4: query = query.Where(s => s.Sale >= 0.3 && s.Sale < 0.7); break;
                case 5: query = query.Where(s => s.Sale >= 0.7 && s.Sale < 1.0); break;
            }

            displayed.Clear();
            foreach (var s in query) displayed.Add(s);

            ServicesList.ItemsSource = displayed;
            StatusText.Text = $"Показано {displayed.Count} из {allServices.Count} услуг";
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();
        private void SaleFilterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();

        private void SortAscBtn_Click(object sender, RoutedEventArgs e)
        {
            var sorted = displayed.OrderBy(s => s.Cost).ToList();
            displayed.Clear();
            foreach (var s in sorted) displayed.Add(s);
        }

        private void SortDescBtn_Click(object sender, RoutedEventArgs e)
        {
            var sorted = displayed.OrderByDescending(s => s.Cost).ToList();
            displayed.Clear();
            foreach (var s in sorted) displayed.Add(s);
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            if (!IsAdmin) return;

            var editWindow = new EditServiceWindow(null);
            editWindow.ServiceUpdated += (s, ev) => LoadServices();
            editWindow.ShowDialog();
        }

        private void EditService_Click(object sender, RoutedEventArgs e)
        {
            if (!IsAdmin) return;

            if (sender is Button btn && long.TryParse(btn.Tag.ToString(), out long id))
            {
                var service = db.Services.FirstOrDefault(s => s.ServiceID == id);
                if (service != null)
                {
                    var editWindow = new EditServiceWindow(service);
                    editWindow.ServiceUpdated += (s, ev) =>
                    {
                        using (var freshDb = new BeautySalonEntities2())
                        {
                            var updatedService = freshDb.Services.FirstOrDefault(x => x.ServiceID == id);
                            if (updatedService != null)
                            {
                                var vm = displayed.FirstOrDefault(x => x.ServiceID == id);
                                if (vm != null)
                                    vm.UpdateFromEntity(updatedService);
                                else
                                    displayed.Add(ServiceVM.FromEntity(updatedService));
                            }
                        }
                    };
                    editWindow.ShowDialog();
                }
            }
        }
        private void Logo_Click(object sender, MouseButtonEventArgs e)
        {
            LoginWindow lw = new LoginWindow();
            lw.Show();
            this.Close();
        }

    

        private void DeleteService_Click(object sender, RoutedEventArgs e)
        {
            if (!IsAdmin) return;

            if (sender is Button btn && long.TryParse(btn.Tag?.ToString(), out long id))
            {
                var service = db.Services.FirstOrDefault(s => s.ServiceID == id);
                if (service == null) return;

                var records = db.Records.Where(r => r.ServiceID == id).ToList();

                bool hasFutureRecords = records.Any(r =>
                {
                    if (string.IsNullOrWhiteSpace(r.ServiceStart)) return false;

                    if (DateTime.TryParseExact(r.ServiceStart.Trim(), "dd.MM.yyyy HH:mm:ss",
                                               CultureInfo.InvariantCulture,
                                               DateTimeStyles.None, out DateTime start))
                    {
                        return start > DateTime.Now;
                    }
                    return false;
                });

                if (hasFutureRecords)
                {
                    MessageBox.Show("Эту услугу нельзя удалить: на неё есть предстоящие записи.",
                        "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (MessageBox.Show("Удалить услугу?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    try
                    {
                        db.Services.Remove(service);
                        db.SaveChanges();
                        LoadServices();
                        MessageBox.Show("Услуга успешно удалена.", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении услуги: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        private void OpenRecords_Click(object sender, RoutedEventArgs e)
        {
            RecordsWindow rw = new RecordsWindow();
            rw.ShowDialog();
        }
    }
}
