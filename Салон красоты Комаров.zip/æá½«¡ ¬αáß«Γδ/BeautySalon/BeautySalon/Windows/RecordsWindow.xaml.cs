﻿using BeautySalon.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BeautySalon
{
    public partial class RecordsWindow : Window
    {
        private readonly BeautySalonEntities2 db = new BeautySalonEntities2();
        private List<RecordVM> allRecords = new List<RecordVM>();
        private ObservableCollection<RecordVM> displayed = new ObservableCollection<RecordVM>();

        public RecordsWindow()
        {
            InitializeComponent();

            if (RecordsList != null) RecordsList.ItemsSource = displayed;

            InitializeFilters();
            LoadRecords();
        }
        private void InitializeFilters()
        {
            if (FilterCombo == null) return;

            FilterCombo.Items.Clear();
            FilterCombo.Items.Add("Все записи");
            FilterCombo.Items.Add("Предстоящие");
            FilterCombo.Items.Add("Прошедшие");
            FilterCombo.SelectedIndex = 0;
        }
        //загрузка записей
        public void LoadRecords()
        {
            try
            {
                allRecords.Clear();
                var records = db.Records.ToList();

                allRecords = records
                    .Select(r => RecordVM.FromEntity(r, db))
                    .Where(r => r != null)
                    .ToList();

                ApplyFilters();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки записей: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private void ApplyFilters()
        {
            if (displayed == null) return;

            string search = SearchBox?.Text?.Trim().ToLower() ?? "";
            var query = allRecords.AsEnumerable();

            if (!string.IsNullOrEmpty(search))
            {
                query = query.Where(r =>
                    (!string.IsNullOrEmpty(r.ServiceName) && r.ServiceName.ToLower().Contains(search)) ||
                    (!string.IsNullOrEmpty(r.ClientFIO) && r.ClientFIO.ToLower().Contains(search)) ||
                    (!string.IsNullOrEmpty(r.ClientPhone) && r.ClientPhone.Contains(search))
                );
            }

            if (FilterCombo != null)
            {
                switch (FilterCombo.SelectedIndex)
                {
                    case 1: query = query.Where(r => r.EndDateTime >= DateTime.Now); break;
                    case 2: query = query.Where(r => r.EndDateTime < DateTime.Now); break;
                }
            }

            if (SortAscRadio?.IsChecked == true) query = query.OrderBy(r => r.StartDateTime);
            else if (SortDescRadio?.IsChecked == true) query = query.OrderByDescending(r => r.StartDateTime);

            displayed.Clear();
            foreach (var r in query) displayed.Add(r);

            if (StatusText != null)
                StatusText.Text = $"Показано {displayed.Count} из {allRecords.Count} записей";
        }
        private void AddRecord_Click(object sender, RoutedEventArgs e)
        {
            var win = new EditRecordWindow();
            win.RecordSaved += (s, ev) => LoadRecords();
            win.ShowDialog();
        }
        private void EditRecord_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && long.TryParse(btn.Tag?.ToString(), out long id))
            {
                var record = db.Records.FirstOrDefault(r => r.RecordID == id);
                if (record != null)
                {
                    var win = new EditRecordWindow(record);
                    win.RecordSaved += (s, ev) => LoadRecords();
                    win.ShowDialog();
                }
            }
        }
        private void DeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && long.TryParse(btn.Tag?.ToString(), out long id))
            {
                var record = db.Records.FirstOrDefault(r => r.RecordID == id);
                if (record != null)
                {
                    if (MessageBox.Show("Удалить запись?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                    {
                        try
                        {
                            db.Records.Remove(record);
                            db.SaveChanges();
                            LoadRecords();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Ошибка удаления: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
            }
        }
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e) => ApplyFilters();
        private void FilterCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) => ApplyFilters();
        private void SortRadio_Checked(object sender, RoutedEventArgs e) => ApplyFilters();
    }
    public class RecordVM
    {
        public long RecordID { get; set; }
        public string ServiceName { get; set; }
        public string ClientFIO { get; set; }
        public string ClientPhone { get; set; }
        public ImageSource Thumbnail { get; set; }
        public string DateRange { get; set; }
        public DateTime StartDateTime { get; set; }
        public DateTime EndDateTime { get; set; }

        public static RecordVM FromEntity(Records record, BeautySalonEntities2 db)
        {
            if (record == null) return null;

            var service = db.Services.FirstOrDefault(s => s.ServiceID == record.ServiceID);
            var client = db.Clients.FirstOrDefault(c => c.ClientID == record.ClientID);

            string fio = client != null ? $"{client.Surname} {client.Name} {client.MiddleName}".Trim() : "—";
            string phone = client?.PhoneNumber ?? "—";

            DateTime start = DateTime.MinValue;
            if (!string.IsNullOrEmpty(record.ServiceStart))
                DateTime.TryParseExact(record.ServiceStart, "dd.MM.yyyy HH:mm:ss", CultureInfo.InvariantCulture, DateTimeStyles.None, out start);

            DateTime end = start;
            if (service != null) end = start.AddMinutes(service.Duration);

            return new RecordVM
            {
                RecordID = record.RecordID,
                ServiceName = service?.ServiceName ?? "—",
                ClientFIO = fio,
                ClientPhone = phone,
                Thumbnail = LoadImageSafe(service?.Image),
                StartDateTime = start,
                EndDateTime = end,
                DateRange = start != DateTime.MinValue ? $"{start:dd.MM.yyyy HH:mm} - {end:dd.MM.yyyy HH:mm}" : "—"
            };
        }
        private static ImageSource LoadImageSafe(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return null;
            try
            {
                path = path.Trim('"');
                if (!System.IO.Path.IsPathRooted(path))
                    path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
                if (!System.IO.File.Exists(path)) return null;
                BitmapImage bmp = new BitmapImage();
                bmp.BeginInit();
                bmp.CacheOption = BitmapCacheOption.OnLoad;
                bmp.UriSource = new Uri(path);
                bmp.DecodePixelWidth = 120;
                bmp.EndInit();
                bmp.Freeze();
                return bmp;
            }
            catch { return null; }
        }
    }
}
