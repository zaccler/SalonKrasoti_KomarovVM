﻿using System.Windows;
using System.Windows.Input;

namespace BeautySalon.Windows
{
    public partial class LoginWindow : Window
    {
        private const string AdminPassword = "0000";

        public LoginWindow()
        {
            InitializeComponent();
        }
        private void ClientButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow(false);
            mainWindow.Show();
            this.Close();
        }

        private void AdminButton_Click(object sender, RoutedEventArgs e)
        {
            AdminPasswordPanel.Visibility = Visibility.Visible;
            AdminButton.Visibility = Visibility.Collapsed;
            ClientButton.Visibility = Visibility.Collapsed;
        }

   
        private void Logo_Click(object sender, MouseButtonEventArgs e)
        {
            LoginWindow lw = new LoginWindow();
            lw.Show();
            this.Close();
        }

        private void LoginAdminButton_Click(object sender, RoutedEventArgs e)
        {
            if (AdminPasswordBox.Password == AdminPassword)
            {
                MainWindow mainWindow = new MainWindow(true);
                mainWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный пароль администратора!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                AdminPasswordBox.Password = "";
            }
        }
    }
}