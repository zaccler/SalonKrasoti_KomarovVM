﻿using BeautySalon.Model;
using Microsoft.Win32;
using System;
using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using System.ComponentModel;
using System.Linq;

namespace BeautySalon
{
    public partial class EditServiceWindow : Window, INotifyPropertyChanged
    {
        private Services _service;
        private string _imagePath;

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string prop) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));

        public event EventHandler ServiceUpdated;

        public string WindowTitle => _service == null ? "Добавление услуги" : "Редактирование услуги";

        private string _serviceName;
        public string ServiceName { get => _serviceName; set { _serviceName = value; OnPropertyChanged(nameof(ServiceName)); } }

        private int? _duration;
        public int? Duration { get => _duration; set { _duration = value; OnPropertyChanged(nameof(Duration)); } }

        private string _cost;
        public string Cost { get => _cost; set { _cost = value; OnPropertyChanged(nameof(Cost)); } }

        private double? _salePercent;
        public double? SalePercent { get => _salePercent; set { _salePercent = value; OnPropertyChanged(nameof(SalePercent)); } }

        private BitmapImage _imagePreview;
        public BitmapImage ImagePreview { get => _imagePreview; set { _imagePreview = value; OnPropertyChanged(nameof(ImagePreview)); } }

        public EditServiceWindow(Services service)
        {
            InitializeComponent();
            _service = service;
            DataContext = this;
            LoadServiceData();
        }
        private void LoadServiceData()
        {
            if (_service != null)
            {
                ServiceName = _service.ServiceName;
                Duration = _service.Duration;
                Cost = _service.Cost.ToString();
                SalePercent = _service.Sale * 100;
                _imagePath = _service.Image;

                if (!string.IsNullOrEmpty(_imagePath))
                    LoadImagePreview(_imagePath);
            }
        }
        private void LoadImagePreview(string imagePath)
        {
            try
            {
                if (File.Exists(imagePath))
                    ImagePreview = new BitmapImage(new Uri(imagePath));
                else
                    ImagePreview = null;
            }
            catch
            {
                ImagePreview = null;
            }
        }
        private void SelectImage_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "Image files (*.jpg;*.jpeg;*.png;*.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All files (*.*)|*.*",
                Title = "Выберите изображение услуги"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                _imagePath = openFileDialog.FileName;
                LoadImagePreview(_imagePath);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (var db = new BeautySalonEntities2())
                {
                    Services service;

                    if (_service == null)
                    {
                        service = new Services();
                        long maxId = db.Services.Any() ? db.Services.Max(s => s.ServiceID) : 0;
                        service.ServiceID = maxId + 1;
                        db.Services.Add(service);
                    }
                    else
                    {
                        service = db.Services.Find(_service.ServiceID);
                        if (service == null)
                        {
                            MessageBox.Show("Услуга не найдена в базе данных", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }
                    }

                    service.ServiceName = ServiceName;
                    service.Duration = Duration.Value;
                    service.Cost = int.Parse(Cost);
                    service.Sale = SalePercent.HasValue ? SalePercent.Value / 100.0 : 0;

                    if (!string.IsNullOrEmpty(_imagePath))
                    {
                        var appDirectory = AppDomain.CurrentDomain.BaseDirectory;
                        var imagesDirectory = Path.Combine(appDirectory, "Images");
                        if (!Directory.Exists(imagesDirectory))
                            Directory.CreateDirectory(imagesDirectory);

                        var fileName = $"{Guid.NewGuid()}{Path.GetExtension(_imagePath)}";
                        var destinationPath = Path.Combine(imagesDirectory, fileName);

                        File.Copy(_imagePath, destinationPath, true);
                        service.Image = destinationPath;
                    }
                    else if (_service == null)
                        service.Image = "";

                    db.SaveChanges();

                    _service = service;
                    LoadServiceData();

                    ServiceUpdated?.Invoke(this, EventArgs.Empty);

                    DialogResult = true;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        private bool ValidateInput()
        {
            if (string.IsNullOrWhiteSpace(ServiceName))
            {
                MessageBox.Show("Введите название услуги", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!int.TryParse(DurationTextBox.Text, out int duration) || duration <= 0)
            {
                MessageBox.Show("Введите корректную длительность (в минутах)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            Duration = duration;

            if (!int.TryParse(CostTextBox.Text, out int cost) || cost <= 0)
            {
                MessageBox.Show("Введите корректную стоимость", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            Cost = cost.ToString();

            if (!double.TryParse(SaleTextBox.Text, out double sale) || sale < 0 || sale > 100)
            {
                MessageBox.Show("Введите корректную скидку (0-100%)", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            SalePercent = sale;

            return true;
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}
